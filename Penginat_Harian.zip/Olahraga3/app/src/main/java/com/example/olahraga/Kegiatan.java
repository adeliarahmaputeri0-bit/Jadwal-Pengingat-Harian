package com.example.olahraga;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Satu kegiatan olahraga, misalnya "Jogging sore" jam 16:30. */
public class Kegiatan {
    private final long id;
    private final String name;
    private final int hour;
    private final int minute;
    // Tanggal terakhir kegiatan ditandai selesai ("" jika belum pernah)
    private String doneDate;

    public Kegiatan(long id, String name, int hour, int minute, String doneDate) {
        this.id = id;
        this.name = name;
        this.hour = hour;
        this.minute = minute;
        this.doneDate = doneDate == null ? "" : doneDate;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public int getHour() { return hour; }
    public int getMinute() { return minute; }
    public String getDoneDate() { return doneDate; }

    public int getMinutesOfDay() { return hour * 60 + minute; }

    public String getTimeText() {
        return String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
    }

    // Dianggap selesai hanya jika ditandai pada tanggal yang sama.
    // Jadi besok centangnya otomatis kosong lagi, tapi daftar kegiatan tetap ada.
    public boolean isDoneOn(String today) {
        return today.equals(doneDate);
    }

    public void setDone(boolean done, String today) {
        doneDate = done ? today : "";
    }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }
}
