package com.example.olahraga;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class KegiatanAdapter extends RecyclerView.Adapter<KegiatanAdapter.VH> {

    private final Context context;
    private final ArrayList<Kegiatan> list;
    private final Runnable onChanged; // dipanggil saat ada centang/hapus
    private boolean dark = false;

    public KegiatanAdapter(Context context, ArrayList<Kegiatan> list, Runnable onChanged) {
        this.context = context;
        this.list = list;
        this.onChanged = onChanged;
    }

    public void setDark(boolean dark) {
        this.dark = dark;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_kegiatan, parent, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Kegiatan k = list.get(position);
        boolean done = k.isDoneOn(Kegiatan.today());

        // Warna kartu, teks, dan chip jam mengikuti mode terang/gelap
        Warna.warnai(holder.itemView, Warna.kartu(dark));
        Warna.warnai(holder.tvTime, Warna.chip(dark));
        holder.tvName.setText(k.getName());
        holder.tvName.setTextColor(done ? Warna.teksSekunder(dark) : Warna.teks(dark));
        holder.tvTime.setText(k.getTimeText());
        holder.tvTime.setTextColor(Warna.aksenTeks(dark));
        setStrike(holder.tvName, done);

        holder.cbDone.setButtonTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{Warna.HIJAU, Warna.teksSekunder(dark)}));

        // Reset listener lama agar tidak terpicu saat scroll
        holder.cbDone.setOnCheckedChangeListener(null);
        holder.cbDone.setChecked(done);
        holder.cbDone.setOnCheckedChangeListener((buttonView, isChecked) -> {
            k.setDone(isChecked, Kegiatan.today());
            KegiatanStorage.save(context, list);
            setStrike(holder.tvName, isChecked);
            holder.tvName.setTextColor(isChecked ? Warna.teksSekunder(dark) : Warna.teks(dark));
            onChanged.run();
        });

        holder.btnDelete.setOnClickListener(v -> {
            int pos = holder.getAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {
                list.remove(pos);
                KegiatanStorage.save(context, list);
                notifyItemRemoved(pos);
                onChanged.run();
                Toast.makeText(context, "Kegiatan dihapus", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setStrike(TextView tv, boolean strike) {
        if (strike) {
            tv.setPaintFlags(tv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            tv.setPaintFlags(tv.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class VH extends RecyclerView.ViewHolder {
        CheckBox cbDone;
        TextView tvName, tvTime;
        ImageButton btnDelete;

        public VH(@NonNull View itemView) {
            super(itemView);
            cbDone = itemView.findViewById(R.id.cbDone);
            tvName = itemView.findViewById(R.id.tvName);
            tvTime = itemView.findViewById(R.id.tvTime);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
