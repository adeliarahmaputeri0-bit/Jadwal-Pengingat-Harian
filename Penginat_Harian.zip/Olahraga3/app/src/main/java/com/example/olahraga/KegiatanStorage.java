package com.example.olahraga;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Menyimpan daftar kegiatan sebagai teks JSON di SharedPreferences. */
public class KegiatanStorage {
    private static final String PREF_NAME = "kegiatan_prefs";
    private static final String KEY_LIST = "kegiatan_list";

    public static void save(Context context, List<Kegiatan> list) {
        JSONArray array = new JSONArray();
        for (Kegiatan k : list) {
            try {
                JSONObject obj = new JSONObject();
                obj.put("id", k.getId());
                obj.put("name", k.getName());
                obj.put("hour", k.getHour());
                obj.put("minute", k.getMinute());
                obj.put("doneDate", k.getDoneDate());
                array.put(obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_LIST, array.toString()).apply();
    }

    public static ArrayList<Kegiatan> load(Context context) {
        ArrayList<Kegiatan> result = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_LIST, null);
        if (json != null) {
            try {
                JSONArray array = new JSONArray(json);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    result.add(new Kegiatan(
                            obj.getLong("id"),
                            obj.getString("name"),
                            obj.getInt("hour"),
                            obj.getInt("minute"),
                            obj.optString("doneDate", "")));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // Urutkan berdasarkan jam
        Collections.sort(result, (a, b) ->
                Integer.compare(a.getMinutesOfDay(), b.getMinutesOfDay()));
        return result;
    }
}
