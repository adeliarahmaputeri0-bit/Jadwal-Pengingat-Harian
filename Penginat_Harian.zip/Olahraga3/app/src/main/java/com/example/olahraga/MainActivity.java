package com.example.olahraga;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private PrefsManager prefs;
    private LinearLayout root;
    private TextView tvGreeting, tvSummary, tvNext, tvLabel, tvEmpty;
    private ProgressBar progressBar;
    private Button btnSettings;
    private RecyclerView rvKegiatan;
    private KegiatanAdapter adapter;
    private final ArrayList<Kegiatan> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PrefsManager(this);
        root = findViewById(R.id.root);
        tvGreeting = findViewById(R.id.tvGreeting);
        tvSummary = findViewById(R.id.tvSummary);
        tvNext = findViewById(R.id.tvNext);
        tvLabel = findViewById(R.id.tvLabel);
        tvEmpty = findViewById(R.id.tvEmpty);
        progressBar = findViewById(R.id.progressBar);
        rvKegiatan = findViewById(R.id.rvKegiatan);
        Button btnAdd = findViewById(R.id.btnAdd);
        btnSettings = findViewById(R.id.btnSettings);

        Warna.padSystemBars(root);

        adapter = new KegiatanAdapter(this, list, this::refreshInfo);
        rvKegiatan.setLayoutManager(new LinearLayoutManager(this));
        rvKegiatan.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> showNameDialog());
        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
    }

    // Pengaturan dibaca ulang dari SharedPreferences setiap layar tampil
    @Override
    protected void onResume() {
        super.onResume();

        boolean dark = prefs.isDark();
        root.setBackgroundColor(Warna.background(dark));
        Warna.statusBar(this, root, dark);
        tvLabel.setTextColor(Warna.teks(dark));
        tvEmpty.setTextColor(Warna.teksSekunder(dark));
        btnSettings.setTextColor(Warna.aksenTeks(dark));
        tvGreeting.setText("Halo, " + prefs.getName() + "! \uD83C\uDFC3");

        list.clear();
        list.addAll(KegiatanStorage.load(this));
        adapter.setDark(dark);
        refreshInfo();
    }

    // Langkah 1: isi nama kegiatan
    private void showNameDialog() {
        EditText input = new EditText(this);
        input.setHint("Contoh: Jogging sore");

        new AlertDialog.Builder(this)
                .setTitle("Nama kegiatan")
                .setView(input)
                .setPositiveButton("Lanjut", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Nama kegiatan tidak boleh kosong",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        showTimePicker(name);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // Langkah 2: pilih jam kegiatan
    private void showTimePicker(String name) {
        Calendar now = Calendar.getInstance();
        new TimePickerDialog(this, (view, hour, minute) -> {
            list.add(new Kegiatan(System.currentTimeMillis(), name, hour, minute, ""));
            Collections.sort(list, (a, b) ->
                    Integer.compare(a.getMinutesOfDay(), b.getMinutesOfDay()));
            KegiatanStorage.save(this, list);
            adapter.notifyDataSetChanged();
            refreshInfo();
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show();
    }

    // Menampilkan ringkasan, progres, dan kegiatan berikutnya
    private void refreshInfo() {
        String today = Kegiatan.today();
        int total = list.size();
        int done = 0;
        for (Kegiatan k : list) {
            if (k.isDoneOn(today)) done++;
        }

        if (total == 0) {
            tvSummary.setText("Belum ada kegiatan hari ini");
        } else {
            tvSummary.setText(done + " dari " + total + " kegiatan selesai");
        }
        progressBar.setMax(total == 0 ? 1 : total);
        progressBar.setProgress(done);

        rvKegiatan.setVisibility(total == 0 ? View.GONE : View.VISIBLE);
        tvEmpty.setVisibility(total == 0 ? View.VISIBLE : View.GONE);

        if (!prefs.isReminderOn()) {
            tvNext.setText("\uD83D\uDD15 Pengingat nonaktif");
            return;
        }

        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        Kegiatan next = null;
        for (Kegiatan k : list) {
            if (!k.isDoneOn(today) && k.getMinutesOfDay() >= nowMinutes) {
                next = k;
                break;
            }
        }

        if (next != null) {
            tvNext.setText("\uD83D\uDD14 Berikutnya: " + next.getName() + " jam " + next.getTimeText());
        } else if (total > 0) {
            tvNext.setText("\uD83D\uDD14 Tidak ada kegiatan berikutnya hari ini");
        } else {
            tvNext.setText("\uD83D\uDD14 Tambah kegiatan untuk mulai diingatkan");
        }
    }
}
