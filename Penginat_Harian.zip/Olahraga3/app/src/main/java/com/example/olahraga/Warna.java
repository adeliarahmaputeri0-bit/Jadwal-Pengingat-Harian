package com.example.olahraga;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

/** Palet warna terang/gelap dan fungsi bantu tampilan. Ubah warna utama di sini. */
public class Warna {

    public static final int HIJAU = Color.parseColor("#16A34A");

    public static int background(boolean dark) {
        return Color.parseColor(dark ? "#0F1512" : "#F1F6F2");
    }

    public static int kartu(boolean dark) {
        return Color.parseColor(dark ? "#1C2622" : "#FFFFFF");
    }

    public static int teks(boolean dark) {
        return Color.parseColor(dark ? "#F1F5F2" : "#14231A");
    }

    public static int teksSekunder(boolean dark) {
        return Color.parseColor(dark ? "#9DB0A5" : "#5B6B61");
    }

    public static int chip(boolean dark) {
        return Color.parseColor(dark ? "#24352C" : "#E6F4EA");
    }

    public static int aksenTeks(boolean dark) {
        return Color.parseColor(dark ? "#4ADE80" : "#15803D");
    }

    // Mengganti warna isi drawable berbentuk shape (kartu / chip)
    public static void warnai(View view, int color) {
        Drawable d = view.getBackground();
        if (d instanceof GradientDrawable) {
            ((GradientDrawable) d.mutate()).setColor(color);
        }
    }

    // Beri jarak dari status bar dan navigation bar (layar penuh di Android 15)
    public static void padSystemBars(View root) {
        final int pad = (int) (20 * root.getResources().getDisplayMetrics().density + 0.5f);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(pad + bars.left, pad + bars.top, pad + bars.right, pad + bars.bottom);
            return insets;
        });
    }

    // Ikon status bar gelap di mode terang, terang di mode gelap
    public static void statusBar(Activity activity, View root, boolean dark) {
        WindowCompat.getInsetsController(activity.getWindow(), root).setAppearanceLightStatusBars(!dark);
        WindowCompat.getInsetsController(activity.getWindow(), root).setAppearanceLightNavigationBars(!dark);
    }
}
