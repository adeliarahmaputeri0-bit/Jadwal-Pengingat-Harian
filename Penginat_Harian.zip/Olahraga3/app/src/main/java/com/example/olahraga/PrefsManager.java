package com.example.olahraga;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Mengelola PENGATURAN aplikasi (data kecil, key-value) dengan SharedPreferences.
 * Daftar kegiatan ditangani KegiatanStorage.
 */
public class PrefsManager {
    private static final String PREF_NAME = "olahraga_settings";
    private static final String KEY_NAME = "username";
    private static final String KEY_REMINDER_ON = "reminder_on";
    private static final String KEY_DARK = "dark_mode";

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveSettings(String name, boolean reminderOn, boolean dark) {
        prefs.edit()
                .putString(KEY_NAME, name)
                .putBoolean(KEY_REMINDER_ON, reminderOn)
                .putBoolean(KEY_DARK, dark)
                .apply(); // simpan di background
    }

    public String getName() { return prefs.getString(KEY_NAME, "Pengguna"); }
    public boolean isReminderOn() { return prefs.getBoolean(KEY_REMINDER_ON, true); }
    public boolean isDark() { return prefs.getBoolean(KEY_DARK, false); }
}
