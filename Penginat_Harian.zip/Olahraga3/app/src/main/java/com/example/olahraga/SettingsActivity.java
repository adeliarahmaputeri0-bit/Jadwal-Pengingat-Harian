package com.example.olahraga;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private PrefsManager prefs;
    private LinearLayout root, card1, card2, card3;
    private TextView tvTitle, lbl1, lbl2, lbl3;
    private EditText etName;
    private Switch swReminder, swDark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = new PrefsManager(this);
        root = findViewById(R.id.rootSettings);
        card1 = findViewById(R.id.card1);
        card2 = findViewById(R.id.card2);
        card3 = findViewById(R.id.card3);
        tvTitle = findViewById(R.id.tvTitle);
        lbl1 = findViewById(R.id.lbl1);
        lbl2 = findViewById(R.id.lbl2);
        lbl3 = findViewById(R.id.lbl3);
        etName = findViewById(R.id.etName);
        swReminder = findViewById(R.id.swReminder);
        swDark = findViewById(R.id.swDark);
        Button btnSave = findViewById(R.id.btnSave);

        Warna.padSystemBars(root);

        // Tampilkan nilai yang sudah tersimpan
        etName.setText(prefs.getName());
        swReminder.setChecked(prefs.isReminderOn());
        swDark.setChecked(prefs.isDark());

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty()) name = "Pengguna";
            prefs.saveSettings(name, swReminder.isChecked(), swDark.isChecked());
            Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean dark = prefs.isDark();
        root.setBackgroundColor(Warna.background(dark));
        Warna.statusBar(this, root, dark);

        Warna.warnai(card1, Warna.kartu(dark));
        Warna.warnai(card2, Warna.kartu(dark));
        Warna.warnai(card3, Warna.kartu(dark));

        tvTitle.setTextColor(Warna.teks(dark));
        lbl1.setTextColor(Warna.aksenTeks(dark));
        lbl2.setTextColor(Warna.aksenTeks(dark));
        lbl3.setTextColor(Warna.aksenTeks(dark));
        etName.setTextColor(Warna.teks(dark));
        etName.setHintTextColor(Warna.teksSekunder(dark));
        etName.setBackgroundTintList(ColorStateList.valueOf(Warna.HIJAU));
        swReminder.setTextColor(Warna.teks(dark));
        swDark.setTextColor(Warna.teks(dark));
    }
}
